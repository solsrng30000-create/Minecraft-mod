# Magic Wand (NeoForge 1.21.1)

Build:   gradle build        (or ./gradlew build if you copied a wrapper in)
Jar:     build/libs/magicwand-1.0.0.jar
Test:    gradle runClient

Requires JDK 21. Right click = cast, Sneak + right click = switch spell.
Spells: Arcane, Fire, Frost, Lightning.
Recipe: amethyst shard + 2 blaze rods (diagonal).
