package com.example.magicwand;

import net.minecraft.ChatFormatting;
import net.minecraft.core.particles.ParticleOptions;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.network.chat.Component;

public enum Spell {
    ARCANE("arcane", ChatFormatting.LIGHT_PURPLE, ParticleTypes.WITCH, ParticleTypes.ENCHANT, ParticleTypes.END_ROD, 7.0F),
    FIRE("fire", ChatFormatting.GOLD, ParticleTypes.FLAME, ParticleTypes.LAVA, ParticleTypes.LARGE_SMOKE, 5.0F),
    FROST("frost", ChatFormatting.AQUA, ParticleTypes.SNOWFLAKE, ParticleTypes.END_ROD, ParticleTypes.CLOUD, 5.0F),
    LIGHTNING("lightning", ChatFormatting.YELLOW, ParticleTypes.ELECTRIC_SPARK, ParticleTypes.FIREWORK, ParticleTypes.ELECTRIC_SPARK, 4.0F);

    public final String id;
    public final ChatFormatting color;
    public final ParticleOptions trail;
    public final ParticleOptions accent;
    public final ParticleOptions burst;
    public final float damage;

    Spell(String id, ChatFormatting color, ParticleOptions trail, ParticleOptions accent, ParticleOptions burst, float damage) {
        this.id = id;
        this.color = color;
        this.trail = trail;
        this.accent = accent;
        this.burst = burst;
        this.damage = damage;
    }

    public Spell next() {
        Spell[] all = values();
        return all[(ordinal() + 1) % all.length];
    }

    public static Spell byId(int i) {
        Spell[] all = values();
        return all[Math.floorMod(i, all.length)];
    }

    public Component displayName() {
        return Component.translatable("spell.magicwand." + id).withStyle(color);
    }
}
