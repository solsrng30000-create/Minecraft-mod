package com.example.magicwand;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.effect.MobEffectInstance;
import net.minecraft.world.effect.MobEffects;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.LightningBolt;
import net.minecraft.world.entity.LivingEntity;
import net.minecraft.world.entity.projectile.ThrowableProjectile;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.EntityHitResult;
import net.minecraft.world.phys.Vec3;

public class MagicBoltEntity extends ThrowableProjectile {
    private Spell spell = Spell.ARCANE;

    public MagicBoltEntity(EntityType<? extends MagicBoltEntity> type, Level level) {
        super(type, level);
        this.setNoGravity(true);
    }

    public MagicBoltEntity(Level level, LivingEntity owner, Spell spell) {
        super(ModEntities.MAGIC_BOLT.get(), owner, level);
        this.spell = spell;
        this.setNoGravity(true);
    }

    @Override
    public void tick() {
        super.tick();
        if (this.level() instanceof ServerLevel sl && !this.isRemoved()) {
            Vec3 p = this.position();
            sl.sendParticles(spell.trail, p.x, p.y, p.z, 4, 0.06, 0.06, 0.06, 0.01);
            sl.sendParticles(spell.accent, p.x, p.y, p.z, 2, 0.12, 0.12, 0.12, 0.02);
            if (this.tickCount > 60) {
                this.discard();
            }
        }
    }

    @Override
    protected void onHitEntity(EntityHitResult result) {
        super.onHitEntity(result);
        if (this.level().isClientSide) return;

        Entity target = result.getEntity();
        target.hurt(this.damageSources().indirectMagic(this, this.getOwner()), spell.damage);

        switch (spell) {
            case FIRE -> target.setRemainingFireTicks(100);
            case FROST -> {
                if (target instanceof LivingEntity le) {
                    le.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN, 100, 2));
                }
            }
            case ARCANE -> {
                if (target instanceof LivingEntity le) {
                    le.addEffect(new MobEffectInstance(MobEffects.GLOWING, 100, 0));
                }
            }
            default -> { }
        }
        impact(result.getLocation());
    }

    @Override
    protected void onHitBlock(BlockHitResult result) {
        super.onHitBlock(result);
        if (this.level().isClientSide) return;
        impact(result.getLocation());
    }

    private void impact(Vec3 pos) {
        if (this.level() instanceof ServerLevel sl) {
            sl.sendParticles(spell.burst, pos.x, pos.y, pos.z, 40, 0.4, 0.4, 0.4, 0.12);
            sl.sendParticles(spell.accent, pos.x, pos.y, pos.z, 25, 0.5, 0.5, 0.5, 0.15);

            switch (spell) {
                case FIRE -> {
                    // Explosion hurts entities but does not break blocks
                    sl.explode(this, pos.x, pos.y, pos.z, 1.5F, Level.ExplosionInteraction.NONE);
                }
                case LIGHTNING -> {
                    LightningBolt bolt = EntityType.LIGHTNING_BOLT.create(sl);
                    if (bolt != null) {
                        bolt.moveTo(pos);
                        sl.addFreshEntity(bolt);
                    }
                }
                case FROST -> sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.GLASS_BREAK, SoundSource.PLAYERS, 1.0F, 1.4F);
                case ARCANE -> sl.playSound(null, pos.x, pos.y, pos.z, SoundEvents.AMETHYST_BLOCK_CHIME, SoundSource.PLAYERS, 1.5F, 0.8F);
            }
        }
        this.discard();
    }

    @Override
    public void addAdditionalSaveData(CompoundTag tag) {
        super.addAdditionalSaveData(tag);
        tag.putInt("Spell", spell.ordinal());
    }

    @Override
    public void readAdditionalSaveData(CompoundTag tag) {
        super.readAdditionalSaveData(tag);
        this.spell = Spell.byId(tag.getInt("Spell"));
    }
}
