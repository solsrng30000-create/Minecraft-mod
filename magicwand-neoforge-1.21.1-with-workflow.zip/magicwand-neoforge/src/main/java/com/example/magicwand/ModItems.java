package com.example.magicwand;

import java.util.function.Supplier;

import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.Rarity;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

public class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(MagicWandMod.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, MagicWandMod.MODID);

    public static final DeferredItem<MagicWandItem> MAGIC_WAND = ITEMS.registerItem("magic_wand",
            MagicWandItem::new, new Item.Properties().stacksTo(1).rarity(Rarity.EPIC));

    public static final Supplier<CreativeModeTab> TAB = TABS.register("main", () -> CreativeModeTab.builder()
            .title(Component.translatable("itemGroup.magicwand"))
            .icon(() -> MAGIC_WAND.get().getDefaultInstance())
            .displayItems((params, out) -> out.accept(MAGIC_WAND.get()))
            .build());
}
