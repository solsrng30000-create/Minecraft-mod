package com.example.magicwand;

import java.util.List;

import net.minecraft.core.component.DataComponents;
import net.minecraft.network.chat.Component;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.item.TooltipFlag;
import net.minecraft.world.item.component.CustomData;
import net.minecraft.world.level.Level;

public class MagicWandItem extends Item {
    private static final String TAG = "Spell";

    public MagicWandItem(Properties props) {
        super(props);
    }

    public static Spell getSpell(ItemStack stack) {
        CustomData data = stack.getOrDefault(DataComponents.CUSTOM_DATA, CustomData.EMPTY);
        return Spell.byId(data.copyTag().getInt(TAG));
    }

    public static void setSpell(ItemStack stack, Spell spell) {
        CustomData.update(DataComponents.CUSTOM_DATA, stack, tag -> tag.putInt(TAG, spell.ordinal()));
    }

    @Override
    public InteractionResultHolder<ItemStack> use(Level level, Player player, InteractionHand hand) {
        ItemStack stack = player.getItemInHand(hand);
        Spell spell = getSpell(stack);

        if (player.isShiftKeyDown()) {
            if (!level.isClientSide) {
                Spell next = spell.next();
                setSpell(stack, next);
                player.displayClientMessage(Component.translatable("message.magicwand.spell_selected", next.displayName()), true);
                level.playSound(null, player.getX(), player.getY(), player.getZ(),
                        SoundEvents.ENCHANTMENT_TABLE_USE, SoundSource.PLAYERS, 0.8F, 1.2F);
            }
            return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
        }

        if (!level.isClientSide) {
            MagicBoltEntity bolt = new MagicBoltEntity(level, player, spell);
            bolt.setPos(player.getX(), player.getEyeY() - 0.15, player.getZ());
            bolt.shootFromRotation(player, player.getXRot(), player.getYRot(), 0.0F, 1.8F, 0.0F);
            level.addFreshEntity(bolt);
            level.playSound(null, player.getX(), player.getY(), player.getZ(),
                    SoundEvents.ILLUSIONER_CAST_SPELL, SoundSource.PLAYERS, 1.0F, 1.0F);
            player.getCooldowns().addCooldown(this, 8);
        }
        return InteractionResultHolder.sidedSuccess(stack, level.isClientSide());
    }

    @Override
    public boolean isFoil(ItemStack stack) {
        return true;
    }

    @Override
    public void appendHoverText(ItemStack stack, Item.TooltipContext context, List<Component> tooltip, TooltipFlag flag) {
        tooltip.add(Component.translatable("tooltip.magicwand.current", getSpell(stack).displayName()));
        tooltip.add(Component.translatable("tooltip.magicwand.hint").withStyle(net.minecraft.ChatFormatting.GRAY));
    }
}
