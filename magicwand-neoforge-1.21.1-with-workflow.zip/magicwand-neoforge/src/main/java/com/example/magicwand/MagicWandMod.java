package com.example.magicwand;

import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.common.Mod;

@Mod(MagicWandMod.MODID)
public class MagicWandMod {
    public static final String MODID = "magicwand";

    public MagicWandMod(IEventBus modBus) {
        ModEntities.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModItems.TABS.register(modBus);
    }
}
